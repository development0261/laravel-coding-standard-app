<script>
  <?php if(Session::has('success')): ?>  
     toastr.success("<?php echo e(Session::get('success')); ?>");
     <?php
       Session::forget('success');
     ?>
  <?php endif; ?>

  <?php if(Session::has('info')): ?>
      toastr.info("<?php echo e(Session::get('info')); ?>");
      <?php
        Session::forget('info');
      ?>
  <?php endif; ?>

  <?php if(Session::has('warning')): ?>
      toastr.warning("<?php echo e(Session::get('warning')); ?>");
      <?php
        Session::forget('warning');
      ?>
  <?php endif; ?>

  <?php if(Session::has('error')): ?>
      toastr.error("<?php echo e(Session::get('error')); ?>");        
      <?php
        Session::forget('error');
      ?>
  <?php endif; ?>
</script><?php /**PATH F:\xampp\htdocs\laravel-coding-standard-app\resources\views/layouts/notification.blade.php ENDPATH**/ ?>