
<?php $__env->startSection('title', __('modules.product.menu.show')); ?>
<?php $__env->startSection('content'); ?>
<div class="container">	
	<div>
		<h5><?php echo e(__('modules.product.menu.show')); ?></h5>
	</div>	
	<div class="row mt-5">
		<div class="col-md-12">
			<table class="table table-responsive">
				<tbody>				
				    <tr>
				      	<th scope="row"><?php echo e(__('modules.comman.column_names.product_name')); ?></th>
				      	<td><?php echo e($showProduct->product_name); ?></td>
				    </tr>
				    <tr>
				      	<th scope="row"><?php echo e(__('modules.comman.column_names.product_description')); ?></th>
				      	<td><?php echo e($showProduct->product_description); ?></td>
				    </tr>
				    <tr>
				      	<th scope="row"><?php echo e(__('modules.comman.column_names.product_price')); ?></th>
				      	<td>$ <?php echo e($showProduct->product_price); ?></td>
				    </tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel-coding-standard-app\resources\views/products/show.blade.php ENDPATH**/ ?>