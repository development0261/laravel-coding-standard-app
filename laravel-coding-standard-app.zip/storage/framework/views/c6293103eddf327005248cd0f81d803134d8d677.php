
<?php $__env->startSection('title', __('modules.product.menu.view')); ?>
<?php $__env->startSection('content'); ?>
<div class="container">	
	<div>
		<h5><?php echo e(__('modules.product.menu.view')); ?></h5>
	</div>
	<table class="table table-responsive">
	  	<thead>
		    <tr>
		      	<th scope="col"><?php echo e(__('modules.comman.column_names.id')); ?></th>
		      	<th scope="col"><?php echo e(__('modules.comman.column_names.product_name')); ?></th>
		      	<th scope="col"><?php echo e(__('modules.comman.column_names.category')); ?></th>
		      	<th scope="col"><?php echo e(__('modules.comman.column_names.product_price')); ?></th>
		      	<th scope="col"><?php echo e(__('modules.comman.column_names.actions')); ?></th>
		    </tr>
		</thead>
		<tbody>
			<?php $indexNumber = $allProducts->perPage() * ($allProducts->currentPage() - 1); ?>
			<?php $__empty_1 = true; $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		    <tr>
		      	<th scope="row"><?php echo e(++$indexNumber); ?></th>
		      	<td><?php echo e($product->product_name); ?></td>  
		      	<td><?php echo e($product->category_name); ?></td> 
		      	<td>$ <?php echo e($product->product_price); ?></td>
		      	<td>
		      		<div class="d-flex">
			      		<a class="btn btn-info btn-sm" href="<?php echo e(route('products.show',['id'=> Crypt::encrypt($product->id)])); ?>"><?php echo e(__('modules.comman.buttons.view')); ?></a>
			      		<a class="btn ml-2 btn-warning btn-sm" href="<?php echo e(route('products.edit',['id'=> Crypt::encrypt($product->id)])); ?>"><?php echo e(__('modules.comman.buttons.edit')); ?></a>
			      		<button type="button" onclick="deleteRecord('<?php echo e(encrypt($product->id)); ?>','<?php echo e(route('products.delete',['id' => encrypt($product->id) ])); ?>')" class="btn ml-2 btn-danger btn-sm"><?php echo e(__('modules.comman.buttons.delete')); ?></button></td>
			      	</div>
		    </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		    <tr>
		      	<td colspan="4"><?php echo e(__('modules.comman.messages.no_data')); ?></td>
		    </tr>
		    <?php endif; ?>
		</tbody>
	</table>
	<div class="d-flex justify-content-center">
		<?php echo e($allProducts->links()); ?>

	</div>	
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel-coding-standard-app\resources\views/products/index.blade.php ENDPATH**/ ?>